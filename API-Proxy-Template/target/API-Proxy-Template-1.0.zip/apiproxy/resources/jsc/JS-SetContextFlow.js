context.setVariable("flowContext",context.flow);
setPathSuffix();

